package project.codersera.cricinshort;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class Store extends View {
    //Canvas canvas;
    private int canvasWidth, canvasHeight;
    //private Canvas canvas;
    private int ballX,ballY,ballSpeed = 16,ballXc=0,ballYc=0;

    private Bitmap bgI;

    private Paint ballPaint = new Paint();

    public Store(Context context){
        super(context);
        ballPaint.setColor(Color.RED);
        ballPaint.setAntiAlias(false);
        bgI = BitmapFactory.decodeResource(getResources(),R.drawable.top);
       //canvas = new Canvas(bgI.copy(Bitmap.Config.ARGB_8888, true));
    }

    @Override
    protected void onDraw(Canvas canvas){

        super.onDraw(canvas);
        canvasWidth = getWidth();
        canvasHeight = getHeight();
        if(stat_activity.check==1){
            ballX = canvasWidth/2;
            ballY=canvasHeight/2;
            stat_activity.check = 0;
        }
        switch (stat_activity.where){
            case 1:
                ballX = ballX - ballSpeed;
                break;
            case 2:
                ballX = ballX + ballSpeed;
                break;
            case 3:
                ballY = ballY - ballSpeed;
                break;
            case 4:
                ballY = ballY + ballSpeed;
                break;
            case 5:
                ballX = ballX + ballSpeed;
                ballY = ballY + ballSpeed;
                break;
        }
        if(ballX < 0 || ballY < 0 || ballX > canvasWidth || ballY > canvasHeight){
            ballX = canvasWidth/2;
            ballY=canvasHeight/2;
        }
        canvas.drawCircle(ballX,ballY,10,ballPaint);
    }
}