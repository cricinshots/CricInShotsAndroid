package project.codersera.cricinshort;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.shashank.sony.fancytoastlib.FancyToast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Sign_In extends AppCompatActivity {
TextView new_user,pass_forgot;
ProgressBar login_progressBar;
EditText edit_email,edit_password;
Button button_login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__in);
        new_user = findViewById(R.id.new_user);
        pass_forgot = findViewById(R.id.pass_forgot);
        login_progressBar = findViewById(R.id.progressbarsign);
        login_progressBar.setVisibility(View.INVISIBLE);
        edit_email = findViewById(R.id.login_email);
        edit_password = findViewById(R.id.login_pass);
        button_login = findViewById(R.id.button_login);
        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login_progressBar.setVisibility(View.VISIBLE);
                check_details();
            }
        });
        new_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Sign_In.this,register_activity.class));
            }
        });
        pass_forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login_progressBar.setVisibility(View.VISIBLE);
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(Sign_In.this);
                View mView = getLayoutInflater().inflate(R.layout.forgotpass_dialog, null);
                    Button okay = mView.findViewById(R.id.submit_fgtemail);
                    final EditText edit_fgt_email = mView.findViewById(R.id.fgt_email);
                    mBuilder.setView(mView);
                    final AlertDialog dialog = mBuilder.create();
                    dialog.setIcon(R.mipmap.ic_launcher_round);
                    dialog.show();
                    dialog.setCancelable(true);
                    okay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String fgtEmail = edit_fgt_email.getText().toString().trim();
                            if(TextUtils.isEmpty(fgtEmail)){
                                FancyToast.makeText(Sign_In.this,"Please enter your email id",FancyToast.LENGTH_LONG,FancyToast.WARNING,false).show();
                                //Toast.makeText(Sign_In.this,"Please enter your email id",Toast.LENGTH_LONG).show();
                                login_progressBar.setVisibility(View.INVISIBLE);
                                return;
                            }
                            if(!isEmailValid(fgtEmail)){
                                FancyToast.makeText(Sign_In.this,"Please enter a valid email",FancyToast.LENGTH_LONG,FancyToast.WARNING,false).show();
                                //Toast.makeText(Sign_In.this,"Please enter a valid email", Toast.LENGTH_LONG).show();
                                login_progressBar.setVisibility(View.INVISIBLE);
                                return;
                            }
                            reset_pwd(fgtEmail);
                            dialog.dismiss();
                        }
                    });

            }
        });
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("EXIT", true);
        startActivity(intent);
    }
public void check_details(){
    final String email = edit_email.getText().toString().trim();
    final String password  = edit_password.getText().toString().trim();

    if(TextUtils.isEmpty(email)){
        FancyToast.makeText(this,"Please enter your email id",FancyToast.LENGTH_LONG,FancyToast.ERROR,false).show();
        //Toast.makeText(this,"Please enter your email id",Toast.LENGTH_LONG).show();
        login_progressBar.setVisibility(View.INVISIBLE);
        return;
    }
    if(!isEmailValid(email)){
        FancyToast.makeText(this,"Please enter a valid email",FancyToast.LENGTH_LONG,FancyToast.WARNING,false).show();
        //Toast.makeText(this,"Please enter a valid email", Toast.LENGTH_LONG).show();
        login_progressBar.setVisibility(View.INVISIBLE);
        return;
    }
    if(TextUtils.isEmpty(password)){
        FancyToast.makeText(this,"Please enter your password",FancyToast.LENGTH_LONG,FancyToast.ERROR,false).show();
        //Toast.makeText(this,"Please enter your password",Toast.LENGTH_LONG).show();
        login_progressBar.setVisibility(View.INVISIBLE);
        return;
    }
    edit_email.setText("");
    edit_password.setText("");
    da_login(email,password);

}
    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    public void reset_pwd(String wht_email){
        FancyToast.makeText(this,"An email with instructions to reset your password has been sent to the above email is",FancyToast.LENGTH_LONG,FancyToast.INFO,false).show();
        //Toast.makeText(Sign_In.this,"An email with instructions to reset your password has been sent to the above email is", Toast.LENGTH_LONG).show();
    }
    public void da_login(String email, String password){

        login_progressBar.setVisibility(View.INVISIBLE);
        FancyToast.makeText(this,"Successfully Logged in",FancyToast.LENGTH_LONG,FancyToast.SUCCESS,false).show();
        //Toast.makeText(this,"Login Done",Toast.LENGTH_LONG).show();
    }
}
