package project.codersera.cricinshort;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.StrictMode;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;
import com.shashank.sony.fancytoastlib.FancyToast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;
import java.net.URLEncoder;

public class MyAsyncService extends Service {
    private AtomicBoolean working = new AtomicBoolean(true);
    private Handler handler = new Handler(),handler2;
    int tp =0 ;
    int balln = 1;
    Timer timer;
    JSONObject matchdetails = new JSONObject();
    public static String name_of_bowler, bowler_leftright, name_of_batsman, batsman_leftright,runs,fielder,deep,out,shot,score,over,result,wickets,batsman2;
    String total;
    //String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            while (working.get()) {
                //
            }
        }
    };
    @Override
    public void onCreate() {
        new Thread(runnable).start();
        handler2 = new Handler();
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        /**StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                         StrictMode.setThreadPolicy(policy);
                         HashMap<String, String> map = getBallData(choose_match.matchid);
                         if(map.isEmpty()){
                         // Server has not provided data / Connection has failed / Request parameters were wrong (Perform the request again?)
                         }else{
                         name_of_bowler = map.get("bowler");
                         bowler_leftright = map.get("bowlerleft");
                         name_of_batsman= map.get("batsman");
                         batsman_leftright = map.get("batsmanleft");
                         runs = map.get("run");
                         fielder  = map.get("fielder");
                         deep = map.get("deep");
                         out = map.get("out");
                         shot = map.get("shot");
                         score = map.get("score");
                         over = map.get("over");
                         result= map.get("result");
                         front_activity.batsman1_tag.setText(" ");
                         front_activity.batsman2_tag.setText(name_of_batsman);
                         front_activity.country1_score.setText(score+"/");
                         front_activity.bowler_tag.setText(name_of_bowler);
                         }**/
                        Thread thread = new Thread() {
                            @Override
                            public void run() {
                                Looper.prepare();
                                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                                StrictMode.setThreadPolicy(policy);
                                HashMap<String, String> map = getBallData(choose_match.matchid);
                                balln++;
                                if(map.isEmpty()){
                                    FancyToast.makeText(getApplicationContext(),"Empty hole. Fill up asap.",FancyToast.LENGTH_LONG,FancyToast.WARNING,false).show();
                                    //Toast.makeText(getApplicationContext(),"Wronger place",Toast.LENGTH_LONG).show();
                                    // Server has not provided data / Connection has failed / Request parameters were wrong (Perform the request again?)
                                }else{
                                    name_of_bowler = map.get("bowler");
                                    bowler_leftright = map.get("bowlerleft");
                                    name_of_batsman= map.get("batsman");
                                    batsman_leftright = map.get("batsmanleft");
                                    runs = map.get("run");
                                    fielder  = map.get("fielder");
                                    deep = map.get("deep");
                                    out = map.get("out");
                                    shot = map.get("shot");
                                    score = map.get("score");
                                    over = map.get("over");
                                    result= map.get("result");
                                    wickets = map.get("wickets");
                                    batsman2 = map.get("batsman2");
                                    switch (MainActivity.whereisuser){
                                        case 1:
                                            break;
                                        case 2:
                                            //stat_activity.canceltask = false;
                                            //stat_activity.updatestat();
                                            Object c = new JSONObject();
                                            break;
                                        default:
                                            FancyToast.makeText(getApplicationContext(),"Wrong hole, wrong hole!",FancyToast.LENGTH_LONG,FancyToast.ERROR,false).show();
                                            //Toast.makeText(getApplicationContext(),"Wrong place",Toast.LENGTH_LONG).show();
                                            break;
                                    }
                                }
                                Looper.loop();
                            }
                        };
                        thread.start();
                    }
                });

            }
        },0,5000);
        /**switch (MainActivity.which_req){
         case 0:
         break;
         case 1:
         break;
         case 2:
         break;
         case 3:
         break;
         case 4:
         break;
         default:
         break;
         }**/
        // prepare a notification for user and start service foreground
        //Notification notification;// = ...
        // this will ensure your service won't be killed by Android
        //startForeground(R.id.notification, notification);
    }
    @Override
    public void onDestroy() {
        working.set(false);
        super.onDestroy();
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    String getContentFromServer(String targetf,String requestContent) {
        String total="", appVersion="";
        try {
            PackageInfo pInfo = getApplicationContext().getPackageManager().getPackageInfo(getPackageName(), 0);
            appVersion = pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        try {
            URL urlobj=new URL("https://codersera.tech/"+targetf);
            HttpURLConnection urlCon=(HttpURLConnection)urlobj.openConnection();
            urlCon.setRequestMethod("POST");
            urlCon.setDoOutput(true);
            Thread.sleep(100);
            if(!urlobj.getHost().equals(urlCon.getURL().getHost()))
                throw new Exception(""); 	// Internet provider expects a login.
            urlCon.setRequestProperty("User-Agent","CiSAndroid/"+appVersion);
            OutputStream os=new BufferedOutputStream(urlCon.getOutputStream());
            os.write(requestContent.getBytes());
            os.flush();
            os.close();
            if((urlCon.getResponseCode()!=HttpURLConnection.HTTP_OK)&&(urlCon.getResponseCode()!=HttpURLConnection.HTTP_NOT_MODIFIED))
            {
                Toast.makeText(getApplicationContext(),"Server error occured.\nCode: "+urlCon.getResponseCode(),Toast.LENGTH_LONG).show();
                // Data could not be obtained due to some reason, show an error screen after the above toast message, and optionally send user to Home Activity
                return total; 	// Quit the function with an empty output (if not already quit)
            }
            BufferedReader in=new BufferedReader(new InputStreamReader(urlCon.getInputStream()));
            String line;
            while((line=in.readLine())!=null)
                total+=line;
            urlCon.disconnect();
        }
        catch(Exception e) {
            // Internet has disconnected, inform the user and quit the app.
            Toast.makeText(getApplicationContext(),"We are facing trouble contacting our server.\nPlease check your internet connection.",Toast.LENGTH_LONG).show();
        }
        finally {
            return total;
        }
    }

    HashMap<String,String> getBallData(String selectedMatchId) {
        return getBallData(selectedMatchId,-1);
    }
    HashMap<String,String> getBallData(String selectedMatchId,int ball) {
        HashMap<String,String> finalMap=new HashMap<String,String>();
        if(ball>-1)
            total = getContentFromServer("cricinshort/forapp/mproc/index.php","op=4&in="+selectedMatchId+"&in1="+ball);
        else
            total = getContentFromServer("cricinshort/forapp/mproc/index.php","op=4&in="+selectedMatchId);
        try {
            JSONObject c_input=new JSONObject(total);
            //JSONArray c_input_keys=new JSONArray("[\"bowler\",\"bowlerleft\",\"batsman\",\"batsmanleft\",\"run\",\"fielder\",\"deep\",\"out\",\"short\",\"score\",\"over\",\"result\"]");
            JSONArray c_input_keys=c_input.names();
            for(int i=0;i<c_input_keys.length();i++)
                finalMap.put(c_input_keys.getString(i),c_input.getString(c_input_keys.getString(i)));
        }
        catch(Exception e) {

            Toast.makeText(getApplicationContext(),"Server output is not in expected form.",Toast.LENGTH_LONG).show();
            //Toast.makeText(getApplicationContext(),e.getStackTrace()[0].toString(),Toast.LENGTH_LONG).show();
        }
        return finalMap; 	// Quit the function with an output (empty if an error occurred)
    }

// This function will fetch singular key=>value pairs from matchdetails
/** The resulting HashMap will contain the keys -
 ** * match_index
 ** * id
 ** * start_time
 ** * timeForNextDay
 ** * end_time
 ** * exp_end_time
 ** * state
 ** * dn
 ** * match_desc
 ** * type
 ** * live_coverage
 ** * minor_series
 ** * state_title
 ** * status
 ** * commlinesCount
 **/
    /** Example data:-
     {
     "match_index":9,
     "id":"21697",
     "start_time":"1560074400",
     "timeForNextDay":"false",
     "end_time":"1560333240",
     "exp_end_time":"1560358800",
     "state":"complete",
     "dn":false,
     "match_desc":"County Div 1",
     "type":"TEST",
     "live_coverage":true,
     "minor_series":false,
     "state_title":"Match drawn",
     "status":"Match drawn",
     "commlinesCount":"50 Comm"
     }
     **/
    HashMap<String,String> getSingularMatchDetails(String selectedMatchId) {
        HashMap<String,String> finalMap=new HashMap<String,String>();
        String total=getContentFromServer("cricinshort/forapp/mproc/index.php","op=2&in="+selectedMatchId);
        try {
            JSONObject c_input=new JSONObject(total);
            JSONArray c_input_keys=c_input.names();
            for(int i=0;i<c_input_keys.length();i++)
                finalMap.put(c_input_keys.getString(i),c_input.getString(c_input_keys.getString(i)));
        }
        catch(Exception e) {
            Toast.makeText(getApplicationContext(),"Server output is not in expected form.",Toast.LENGTH_LONG).show();
        }
        return finalMap; 	// Quit the function with an output (empty if an error occurred)
    }
   /** void getMatchDetails(boolean a, String b, JSONObject c, String d) {
        JSONObject x = new JSONObject();
        JSONArray y = new JSONArray();
        if(a) {
            String z = getContentFromServer("cricinshort/forapp/mproc/index.php","op=3&in="+URLEncoder.encode(b,"US-ASCII")+"&in1="+URLEncoder.encode(d,"US-ASCII"));
            b="";
            //d=b; // Saving memory
            try {
                x = new JSONObject(z);
                c.putOpt(d,x);
            }
            catch(JSONException e) {
                try {
                    y = new JSONArray(z);
                    c.putOpt(d,y);
                }
                catch(JSONException e) {return;}
            }
        }
        else {
            d=""; // Saving memory
            String z = getContentFromServer("cricinshort/forapp/mproc/index.php","op=2&in="+ URLEncoder.encode(b,"US-ASCII"));
            b=d; // Saving memory
            try {
                x = new JSONObject(z);
                y = x.names();
                for(int w=0; w<y.length(); w++)
                   // c.putOpt(y.getOpt(w),x.getOpt(y.getOpt(w)));
            }
            catch(JSONException e) {return;}
        }
    }**/
}