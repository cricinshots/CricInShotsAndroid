package project.codersera.cricinshort;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Looper;
import android.os.StrictMode;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.shashank.sony.fancytoastlib.FancyToast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

public class choose_match extends AppCompatActivity {
    ListView choose;
    String[] current_matches;
    String[][] get_Cmatches;
    ArrayList<String> matches;
    String version;
    ProgressBar progressBar;
    SwipeRefreshLayout pullToRefresh3;
    public static String team1,team2,matchid;
    public static boolean match_chosen = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_match);
        matchid = "sample";
        Intent intent = new Intent(choose_match.this, front_activity.class);
        //startActivity(intent);
        matches =  new ArrayList<String>();
        //matches.add("test");
        choose = findViewById(R.id.match_ListView);
        progressBar = findViewById(R.id.progressbarchoose);
        progressBar.setVisibility(View.VISIBLE);
        pullToRefresh3 = findViewById(R.id.pullToRefresh3);
        try {
            PackageInfo pInfo = choose_match.this.getPackageManager().getPackageInfo(getPackageName(), 0);
            version = pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        new Thread(new Runnable() {
            public void run(){
                Looper.prepare();
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                get_Cmatches = getCurrentMatches();
                current_matches = new String[get_Cmatches.length];
                for(int i=0;i<get_Cmatches.length;i++) {
                    current_matches[i]=get_Cmatches[i][1] + "\n" + get_Cmatches[i][3] + " vs " + get_Cmatches[i][4];
                }
                matches.addAll(Arrays.asList(current_matches));
                choose_match.this.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        list();

                    }
                });
                Looper.loop();

                // progressDialog.dismiss();
            }
        }).start();
        //list();
        pullToRefresh3.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                FancyToast.makeText(choose_match.this,"Refreshing...",FancyToast.LENGTH_LONG,FancyToast.CONFUSING,false).show();
                pullToRefresh3.setRefreshing(false);
            }
        });
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("EXIT", true);
        startActivity(intent);
    }
    public void onResume(){
        super.onResume();
        match_chosen = false;
    }

    public void list(){
        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<String>(this,R.layout.custom_listitem, matches);
        // Set The Adapter
        choose.setAdapter(arrayAdapter);
        // register onClickListener to handle click events on each item
        choose.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            // argument position gives the index of item which is clicked
            public void onItemClick(AdapterView<?> arg0, View v,int position, long arg3)
            {
                String selectedmatch = matches.get(position);
                match_chosen = true;
                team1 = get_Cmatches[position][3];
                team2 = get_Cmatches[position][4];
                matchid = get_Cmatches[position][0];
                //Toast.makeText(getApplicationContext(), get_Cmatches[position][0],   Toast.LENGTH_LONG).show();
                FancyToast.makeText(getApplicationContext(),"Match Selected : " + selectedmatch,FancyToast.LENGTH_LONG,FancyToast.INFO,false).show();
                //Toast.makeText(getApplicationContext(), "Match Selected : " + selectedmatch,   Toast.LENGTH_LONG).show();
                /**new Thread(new Runnable() {
                    public void run() {
                        startService(new Intent(getApplicationContext(), MyAsyncService.class));

                    }
                }).start();**/
                Intent intent = new Intent(choose_match.this, front_activity.class);
                //intent.putExtra("Team1",get_Cmatches[position][3]);
                //intent.putExtra("Team2",get_Cmatches[position][4]);
                startActivity(intent);
            }
        });
        progressBar.setVisibility(View.INVISIBLE);
    }
    String getContentFromServer(String targetf,String requestContent)
    {
        String total="", appVersion=version; 	// Done - Put our app's versionName or versionCode in appVersion
        try {
            URL urlobj=new URL("https://codersera.tech/"+targetf);
            HttpURLConnection urlCon=(HttpURLConnection)urlobj.openConnection();
            urlCon.setRequestMethod("POST");
            urlCon.setDoOutput(true);
            Thread.sleep(100);
            if(!urlobj.getHost().equals(urlCon.getURL().getHost()))
                throw new Exception(""); 	// Internet provider expects a login.
            urlCon.setRequestProperty("User-Agent","CiSAndroid/"+appVersion);
            OutputStream os=new BufferedOutputStream(urlCon.getOutputStream());
            os.write(requestContent.getBytes());
            os.flush();
            os.close();
            if((urlCon.getResponseCode()!=HttpURLConnection.HTTP_OK)&&(urlCon.getResponseCode()!=HttpURLConnection.HTTP_NOT_MODIFIED))
            {
                FancyToast.makeText(this,"Server error occured.\nCode: "+urlCon.getResponseCode(),FancyToast.LENGTH_LONG,FancyToast.ERROR,false).show();
                //Toast.makeText(choose_match.this,"Server error occured.\nCode: "+urlCon.getResponseCode(),Toast.LENGTH_LONG).show();
                // Data could not be obtained due to some reason, show an error screen after the above toast message, and optionally send user to Home Activity
                return total; 	// Quit the function with an empty output (if not already quit)
            }
            BufferedReader in=new BufferedReader(new InputStreamReader(urlCon.getInputStream()));
            String line="";
            /* String line=in.readLine();
            if(line.matches("\\.\\..*\\.\\."))
            {
                Toast.makeText(choose_match.this,"Server error occured.\nMessage: "+line.substring(3,(line.length()-3)),Toast.LENGTH_LONG).show();
                return total; 	// Quit the function with an empty output (if not already quit)
            } */ // This method is no longer used to display errors in the current scenario.

            while((line=in.readLine())!=null)
                total+=line;
            urlCon.disconnect();
        }
        catch(Exception e) {
            // Internet has now disconnected, inform the user and quit the app.
            FancyToast.makeText(this,"We are facing trouble contacting our server.\nPlease check your internet connection.",FancyToast.LENGTH_LONG,FancyToast.WARNING,false).show();
            //Toast.makeText(choose_match.this,"We are facing trouble contacting our server.\nPlease check your internet connection.",Toast.LENGTH_LONG).show();
        }
        finally {

            return total;
        }
    }

    /**String[] getCurrentMatches()
     {
     String[] finalArr={""};
     final String total=getContentFromServer("cricinshort/forapp/mproc/index.php","op=0");

     try {
     JSONArray c_input=new JSONArray(total);
     finalArr=new String[c_input.length()];
     for(int i=0;i<c_input.length();i++)
     finalArr[i]=c_input.getString(i);
     }
     catch(Exception e) {
     Toast.makeText(choose_match.this,"Server output is not in expected form.",Toast.LENGTH_LONG).show();

     // Show "Feature temporarily unavailable / Server under maintenance" and redirect user to previous activity or Home Activity.
     //Toast.makeText(getActivity(),e.toString(),Toast.LENGTH_LONG).show();
     }

     return finalArr; 	// Quit the function with an output (empty if an error occurred)
     }**/

    String[][] getCurrentMatches()
    {
        String finalArr[][]={{"",""}}, total=getContentFromServer("cricinshort/forapp/mproc/index.php","op=1");

        try {
            JSONArray c_input=new JSONArray(total);
            finalArr=new String[c_input.length()][5];
            //finalArr[0][0]=c_input.length()+"";
            //finalArr[0][1]="";
            //finalArr[0][2]="";
            for(int i=0;i<=c_input.length();i++)
            {
                JSONObject j=new JSONObject(c_input.getString(i));
                finalArr[i][0]=j.getString("id");
                finalArr[i][1]=j.getString("sname");
                finalArr[i][2]=j.getString("venue");
                finalArr[i][3]=j.getString("team1");
                finalArr[i][4]=j.getString("team2");
            }
        }
        catch(Exception e) {
            FancyToast.makeText(this,"Server output is not in expected form.",FancyToast.LENGTH_LONG,FancyToast.ERROR,false).show();
            //Toast.makeText(choose_match.this,"Server output is not in expected form.",Toast.LENGTH_LONG).show();
        }
        return finalArr; 	// Quit the function with an output (empty if an error occurred)
    }
}
