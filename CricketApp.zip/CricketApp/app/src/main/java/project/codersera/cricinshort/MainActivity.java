package project.codersera.cricinshort;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;

import java.io.File;

    public class MainActivity extends AppCompatActivity {
    String restoredState = "notwelcomed",askedreglogin = "false";
    public static int which_req =0,whereisuser=0;
    static boolean authtoken = false,maintainence_status = false,network_status=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Intent intent = new Intent(MainActivity.this, Azure.class);
        //startActivity(intent);
        if (getIntent().getExtras() != null && getIntent().getExtras().getBoolean("EXIT", false)) {
            deleteCache(MainActivity.this);
            Intent intent = new Intent(MainActivity.this, MyAsyncService.class);
            stopService(intent);
            finish();
            System.exit(0);
        }
        network_check();
    //heapissues
    }
    @Override
    public void onBackPressed() {
        finish();
        System.exit(0);
    }
    public void onDestroy(){
        deleteCache(MainActivity.this);
        super.onDestroy();
        whereisuser=0;
        Intent intent = new Intent(MainActivity.this, MyAsyncService.class);
        stopService(intent);
    }

    public void network_check() {

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            //we are connected to a network true
            network_status = true;
            further_tasks();

        } else {

            network_status = false;
            AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
            alertDialog.setTitle("Connection Error");
            alertDialog.setMessage("Unable to connect with the server.\nPlease check your internet connection and try again.");
            alertDialog.setCancelable(false);
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Exit",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            finish();
                            System.exit(0);
                        }
                    });
            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Retry",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            network_check();
                        }
                    });
            alertDialog.show();

        }
    }
    public boolean version_check(){
        boolean version_deprecated = false;

        return version_deprecated;
    }

    public void maintainence_check(){
        maintainence_status = false;
        if (maintainence_status){
            final android.app.AlertDialog alertDialog = new android.app.AlertDialog.Builder(this).create();
            alertDialog.setTitle("Maintenance Break");
            alertDialog.setMessage("Sorry the servers are under maintenance, please try again in some time.");
            //getString(R.string.p_cont)
            alertDialog.setCancelable(true);
            alertDialog.setIcon(R.mipmap.ic_launcher_round);
            alertDialog.setButton("Retry", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                    maintainence_check();


                }

            });
            alertDialog.show();

        }else{
            tasks();
        }
    }
    public void tasks(){
        if(version_check()){
            final android.app.AlertDialog alertDialog = new android.app.AlertDialog.Builder(this).create();
            alertDialog.setTitle("Version deprecated");
            alertDialog.setMessage("You are using an older version of the app that is not supported any more. Please click on update to get the latest version");
            //getString(R.string.p_cont)
            alertDialog.setCancelable(true);
            alertDialog.setIcon(R.mipmap.ic_launcher_round);
            alertDialog.setButton("Update", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                    //update link redirect to playstore here
                }

            });
            alertDialog.show();
            return;
        }
        maintainence_check();
    }
    public void further_tasks(){
        restoredState = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("Load_State", "notwelcomed");
        restoredState = "welcomed";
        askedreglogin = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("RegLogin_State", "false");
        askedreglogin = "true";
        /**Thread thread = new Thread() {
            @Override
            public void run() {
                startService(new Intent(getApplicationContext(), MyAsyncService.class));
            }
        };
        thread.start();**/
        if (restoredState.equals("welcomed")) {
            //startActivity(new Intent(MainActivity.this, choose_match.class));
            if(askedreglogin.equals("true")){
                startActivity(new Intent(MainActivity.this, choose_match.class));

            }else{
                startActivity(new Intent(MainActivity.this, register_activity.class));
            }

        } else if (restoredState.equals("notwelcomed")) {
            startActivity(new Intent(MainActivity.this, welcome_act.class));
        }
    }

    public static void deleteCache(Context context) {
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) { e.printStackTrace();}
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if(dir!= null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }
}