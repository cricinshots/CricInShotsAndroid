package project.codersera.cricinshort;

public class listadapter {
}
