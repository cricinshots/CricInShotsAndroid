package project.codersera.cricinshort;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.shashank.sony.fancytoastlib.FancyToast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import pl.droidsonroids.gif.GifImageView;

public class stat_activity extends AppCompatActivity {
    private Store gameStore;
    private Handler handler = new Handler();
    public static int check=1,where=0;
    private float canvasWidth, canvasHeight;
    int myrun=0,myout=0;
    private float ballX,ballY,p1X,p1Y,p2X,p2Y,tag1X,tag1Y,tag2X,tag2Y,p1yextent,p2yextent;
    int pspeed=10,ballSpeed = speed_generator();
    private long Interval = 60;
    float ballxpercentage = 51.018517f ,ballypercentage = 55.208332f,p1xpercentage = 53.981483f,p1ypercentage = 55.208332f,p2xpercentage = 50.0f,p2ypercentage = 40.625f;
    int counter = 0;
    ImageButton bck;
    ImageView iv,gv;//= 51.018517 55.208332 53.981483 55.208332 50.0 40.625
    Canvas canvas;
    GifImageView gif;
    Bitmap bitmap;
    Runnable mainRun;
    Timer timer;
    Random random = new Random();
    LinearLayout ball_lin;
    private Paint ballPaint = new Paint();
    private Paint playerPaint = new Paint();
    private Paint tagPaint = new Paint();
    TextView over_deets,scwic;
    float over_num,ball_num,overs_total;
    boolean hua = true,ifgif = false, one_run = false, run_state = false,two_run = false,three_run=  false,actually1 = false,runbtwwckt_comp = false,run_allow = true,canceltask=true,cancel2=true,out=false,four4 = false, six6 = false,wideball = false, noball = false;
    int player_counter = 280,single_run_counter=0;
    String player1,player2,tscore,twickets;
    SwipeRefreshLayout pullToRefresh2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_stat_activity);
        MainActivity.whereisuser=2;
        //getWindow().setWindowAnimations();
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        bitmap = Bitmap.createBitmap(
                width, // Width
                height, // Height
                Bitmap.Config.ARGB_8888 // Config
        );
        canvas = new Canvas(bitmap);
        bck = findViewById(R.id.button_statback);
        gv = findViewById(R.id.iffygif);
        iv = findViewById(R.id.civ);
        ballPaint.setColor(Color.RED);
        ballPaint.setAntiAlias(false);
        playerPaint.setColor(Color.BLUE);
        playerPaint.setAntiAlias(false);
        tagPaint.setColor(Color.BLACK);
        tagPaint.setAntiAlias(false);
        tagPaint.setTextSize(25);
        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();
        //gameStore = new Store(this);
        //setContentView(gameStore);
        //gif = findViewById(R.id.float_gif);
        //gif.setEnabled(false);
        //gif.setVisibility(View.INVISIBLE);
        gv.setEnabled(false);
        gv.setVisibility(View.INVISIBLE);

        //ballX = 551;
        //ballY = 1060;
        //p1X = 583;
        //p1Y = ballY;
        //p2X = 540;
        //p2Y = 780;
        ballX = ballxpercentage/100*canvasWidth;

        ballY = p2ypercentage/100*canvasHeight;//ballypercentage/100*canvasHeight;

        p1X = p1xpercentage/100*canvasWidth;
        p1Y = p1ypercentage/100*canvasHeight;
        p1yextent = p1Y;
        p2X = p2xpercentage/100*canvasWidth;
        p2Y = p2ypercentage/100*canvasHeight;
        p2yextent = p2Y;
        //dia();
        tag1X = p1X - 10;
        tag1Y = p1Y-35;
        tag2X = p2X - 10;
        tag2Y = p2Y + 45;
        over_deets = findViewById(R.id.stat_overdeets);
        scwic = findViewById(R.id.scorewicketstat);
        overs_total = 60;
        over_num = 1;
        ball_num =0;
        player1 = "---";
        over_deets.setText("Overs: "+over_num+"/"+Math.round(overs_total)*1+"\n"+"Ball "+Math.round(ball_num)+" of 6");
        scwic.setText(tscore+"/"+twickets);
        ball_lin = (LinearLayout) findViewById(R.id.lin_balls);
        pullToRefresh2 = findViewById(R.id.pullToRefresh2);
        bck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(stat_activity.this,front_activity.class));

            }
        });
        timerFunc();
        pullToRefresh2.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                FancyToast.makeText(stat_activity.this,"Refreshing...",FancyToast.LENGTH_LONG,FancyToast.CONFUSING,false).show();
                pullToRefresh2.setRefreshing(false);
            }
        });
    }
    @Override
    public void onBackPressed() {
        startActivity(new Intent(stat_activity.this,front_activity.class));
    }
    protected void onPause()
    {
        super.onPause();
        MainActivity.whereisuser=0;
        timer.cancel();
        canceltask = true;



    }
    protected void onResume()
    {
        super.onResume();
        MainActivity.whereisuser=2;
        canceltask = false;
        timerFunc();


    }
    public void onDestroy(){
        MainActivity.whereisuser=0;
        deleteCache(stat_activity.this);
        super.onDestroy();
    }
public void timerFunc(){

    timer = new Timer();
    timer.schedule(new TimerTask() {
        @Override
        public void run() {
            handler.post(new Runnable() {
                @Override
                public void run() {

                    if (true) {//!canceltask
                        if (true){//MyAsyncService.result.equals("0")) {
                        //gameStore.invalidate();
                        updateinfo();
                        canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                        ballSpeed = speed_generator();
                       switch (where) {
                            case 0:
                                ballX = ballX - ballSpeed;
                                break;
                            case 1:
                                ballX = ballX - ballSpeed;
                                break;
                            case 2:
                                ballX = ballX + ballSpeed;
                                break;
                            case 3:
                                ballY = ballY - ballSpeed;
                                break;
                            case 4:
                                ballY = ballY + ballSpeed;
                                break;
                            case 5:
                                ballX = ballX + ballSpeed;
                                ballY = ballY + ballSpeed;
                                break;
                            case 6:
                                ballX = ballX + ballSpeed;
                                break;
                            case 7:
                                ballY = ballY - ballSpeed;
                                break;
                            default:
                                where = 1;
                                break;
                        }

                        if (player_counter <= 0) {
                            run_state = !run_state;
                            player_counter = 280;
                            single_run_counter++;
                            if (actually1) {
                                if (single_run_counter == 1) {
                                    one_run = false;
                                    actually1 = false;
                                    single_run_counter = 0;
                                    run_allow = false;
                                    runbtwwckt_comp = true;
                                }
                            } else if (two_run) {
                                if (single_run_counter == 2) {
                                    one_run = false;
                                    two_run = false;
                                    run_allow = false;
                                    single_run_counter = 0;
                                    runbtwwckt_comp = true;
                                }
                            } else if (three_run) {
                                if (single_run_counter == 3) {
                                    one_run = false;
                                    three_run = false;
                                    single_run_counter = 0;
                                    run_allow = false;
                                    runbtwwckt_comp = true;
                                }
                            }
                            stat_activity.this.runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    //Toast.makeText(stat_activity.this, single_run_counter + "", Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                        if (one_run) {
                            if (!run_state) {
                                if (p1Y > p2yextent || p2Y < p1yextent) {
                                    p1Y = p1Y - pspeed;
                                    p2Y = p2Y + pspeed;
                                    tag1Y = tag1Y - pspeed;
                                    tag2Y = tag2Y + pspeed;

                                }
                            }
                            if (run_state) {
                                if (p1Y < p1yextent || p2Y > p2yextent) {
                                    p1Y = p1Y + pspeed;
                                    p2Y = p2Y - pspeed;
                                    tag1Y = tag1Y + pspeed;
                                    tag2Y = tag2Y - pspeed;
                                }
                            }
                            player_counter = player_counter - pspeed;
                        }

                        if (ballX < 0 || ballY < 0 || ballX > canvasWidth || ballY > canvasHeight) {
                            ballX = ballxpercentage / 100 * canvasWidth;
                            ballY = p2ypercentage/100*canvasHeight;//ballypercentage / 100 * canvasHeight;
                            //canvasWidth = canvas.getWidth();
                            //canvasHeight = canvas.getHeight();
                            //canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                            where++;
                            ball_num++;

                            if (ifgif) {

                                gifdisplay();

                            }

                            if (ball_num % 6 == 0) {
                                over_num++;
                                ball_num = 0;
                            }

                            over_deets.setText("Overs: " + MyAsyncService.over + "/" + overs_total + "\n" + "Ball " + ball_num + " of 6");
                            scwic.setText(tscore+"/"+twickets);

                        } else {


                            canvas.drawCircle(ballX, ballY, 10, ballPaint);
                            canvas.drawCircle(p1X, p1Y, 15, playerPaint);
                            canvas.drawCircle(p2X, p2Y, 15, playerPaint);
                            canvas.drawText(player1, tag1X, tag1Y, tagPaint);
                            canvas.drawText(player2, tag2X, tag2Y, tagPaint);
                            //canvas.drawText();
                            iv.setImageBitmap(bitmap);


                        }
                    }
                }
                }
           });
        }
    },0,Interval);
}

public int speed_generator(){
        int finalspeed;
        Random rand = new Random();
        finalspeed = rand.nextInt((14 - 7) + 1) + 7;
        return finalspeed;
    }
public void gifdisplay(){
    if(six6){
        Thread threadgif = new Thread() {
            @Override
            public void run() {
                stat_activity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        gv.setEnabled(true);
                        gv.setVisibility(View.VISIBLE);
                        Glide.with(stat_activity.this).load("https://codersera.tech/cricinshort/forapp/gifs/anim6.gif").apply(new RequestOptions().override(Target.SIZE_ORIGINAL)).into(gv);
                        ballX = ballX - ballSpeed;
                        six6 = false;
                        ifgif = false;
                        hua = true;
                    }
                });

                //gif.
            }
        };
        threadgif.start();
    }else if(four4){
        Thread threadgif = new Thread() {
            @Override
            public void run() {

                stat_activity.this.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        gv.setEnabled(true);
                        gv.setVisibility(View.VISIBLE);
                        Glide.with(stat_activity.this).load("https://codersera.tech/cricinshort/forapp/gifs/anim4.gif").apply(new RequestOptions().override(Target.SIZE_ORIGINAL)).into(gv);
                        ballX = ballX - ballSpeed;
                        four4 = false;
                        ifgif = false;
                        hua = true;
                    }
                });

                //gif.
            }
        };
        threadgif.start();
    }else if(out){
        Thread threadgif = new Thread() {
            @Override
            public void run() {

                stat_activity.this.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        gv.setEnabled(true);
                        gv.setVisibility(View.VISIBLE);
                        Glide.with(stat_activity.this).load("https://codersera.tech/cricinshort/forapp/gifs/outanim.gif").apply(new RequestOptions().override(Target.SIZE_ORIGINAL)).into(gv);
                        out = false;
                        ifgif = false;
                        hua = true;
                    }
                });

                //gif.
            }
        };
        threadgif.start();
    }else if(wideball){
        Thread threadgif = new Thread() {
            @Override
            public void run() {
                stat_activity.this.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        gv.setEnabled(true);
                        gv.setVisibility(View.VISIBLE);
                        Glide.with(stat_activity.this).load("https://codersera.tech/cricinshort/forapp/gifs/wideanim.gif").apply(new RequestOptions().override(Target.SIZE_ORIGINAL)).into(gv);
                        wideball = false;
                        ifgif = false;
                        hua = true;
                    }
                });


            }
        };
        threadgif.start();
    }else if(noball){
        Thread threadgif = new Thread() {
            @Override
            public void run() {
                stat_activity.this.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        gv.setEnabled(true);
                        gv.setVisibility(View.VISIBLE);
                        Glide.with(stat_activity.this).load("https://codersera.tech/cricinshort/forapp/gifs/noball.gif").apply(new RequestOptions().override(Target.SIZE_ORIGINAL)).into(gv);
                        noball = false;
                        ifgif = false;
                        hua = true;
                    }
                });
            }
        };
        threadgif.start();
    }

}
public void addball(){
    LinearLayout linearLayout = findViewById(R.id.lin_balls);
    LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(
            17, LinearLayout.LayoutParams.WRAP_CONTENT);
    TextView tv=new TextView(stat_activity.this);
    lparams.setMargins(5,5,5,5);
    tv.setLayoutParams(lparams);
    tv.setBackgroundResource(R.drawable.single_bg);
    linearLayout.addView(tv);
}
public void dia(){
    final android.app.AlertDialog alertDialog = new android.app.AlertDialog.Builder(stat_activity.this).create();
    alertDialog.setTitle("Percentages");
    alertDialog.setMessage("ballX = "+ballxpercentage+" ballY = "+ballypercentage+"\np1X = "+p1xpercentage+" p1Y = "+p1ypercentage+" p2X = "+p2xpercentage+" p2Y = "+p2ypercentage);
    //getString(R.string.p_cont)
    alertDialog.setCancelable(true);
    alertDialog.setIcon(R.mipmap.ic_launcher_round);
    alertDialog.setButton("Continue", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
            alertDialog.dismiss();
            dia();
        }

    });
    alertDialog.show();
}
public void updateinfo() {


                            gv.setEnabled(false);
                            gv.setVisibility(View.INVISIBLE);

                                player1 = "Virat";//MyAsyncService.batsman2;
                                player2 = "Dhoni";//MyAsyncService.name_of_batsman;
                                tscore = "150";//MyAsyncService.score;
                                twickets = "3";//MyAsyncService.wickets;

                            myrun = random.nextInt(6 - 1 + 1) + 1;
                            myout = random.nextInt(6 - 1 + 1) + 1;

                            if (myout==1) {
                                ifgif = true;
                                out = true;
                                hua = false;
                            }else {
                                switch (myrun) {
                                    case 0:
                                        break;
                                    case 1:
                                        one_run = true;
                                        actually1 = true;
                                        two_run = false;
                                        three_run = false;
                                        break;
                                    case 2:
                                        one_run = true;
                                        actually1 = false;
                                        two_run = false;
                                        three_run = true;
                                        break;
                                    case 3:
                                        one_run = true;
                                        actually1 = false;
                                        two_run = false;
                                        three_run = true;
                                        break;
                                    case 4:
                                        ifgif = true;
                                        four4 = true;
                                        hua = false;
                                        break;
                                    case 5:
                                        break;
                                    case 6:
                                        ifgif = true;
                                        six6 = true;
                                        hua= false;
                                        break;
                                    default:
                                        break;
                                }
                            }

    }
    public static void deleteCache (Context context){
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean deleteDir (File dir){
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if (dir != null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }
    String getContentFromServer(String targetf,String requestContent)
    {
        String total="", appVersion = "1";//version; 	// Done - Put our app's versionName or versionCode in appVersion
        try {
            URL urlobj=new URL("https://codersera.tech/"+targetf);
            HttpURLConnection urlCon=(HttpURLConnection)urlobj.openConnection();
            urlCon.setRequestMethod("POST");
            urlCon.setDoOutput(true);
            Thread.sleep(100);
            if(!urlobj.getHost().equals(urlCon.getURL().getHost()))
                throw new Exception(""); 	// Internet provider expects a login.
            urlCon.setRequestProperty("User-Agent","CiSAndroid/"+appVersion);
            OutputStream os=new BufferedOutputStream(urlCon.getOutputStream());
            os.write(requestContent.getBytes());
            os.flush();
            os.close();
            if((urlCon.getResponseCode()!=HttpURLConnection.HTTP_OK)&&(urlCon.getResponseCode()!=HttpURLConnection.HTTP_NOT_MODIFIED))
            {
                FancyToast.makeText(this,"Server error occured.\nCode: "+urlCon.getResponseCode(),FancyToast.LENGTH_LONG,FancyToast.ERROR,false).show();
                //Toast.makeText(choose_match.this,"Server error occured.\nCode: "+urlCon.getResponseCode(),Toast.LENGTH_LONG).show();
                // Data could not be obtained due to some reason, show an error screen after the above toast message, and optionally send user to Home Activity
                return total; 	// Quit the function with an empty output (if not already quit)
            }
            BufferedReader in=new BufferedReader(new InputStreamReader(urlCon.getInputStream()));
            String line="";
            /* String line=in.readLine();
            if(line.matches("\\.\\..*\\.\\."))
            {
                Toast.makeText(choose_match.this,"Server error occured.\nMessage: "+line.substring(3,(line.length()-3)),Toast.LENGTH_LONG).show();
                return total; 	// Quit the function with an empty output (if not already quit)
            } */ // This method is no longer used to display errors in the current scenario.

            while((line=in.readLine())!=null)
                total+=line;
            urlCon.disconnect();
        }
        catch(Exception e) {
            // Internet has now disconnected, inform the user and quit the app.
            FancyToast.makeText(this,"We are facing trouble contacting our server.\nPlease check your internet connection.",FancyToast.LENGTH_LONG,FancyToast.WARNING,false).show();
            //Toast.makeText(choose_match.this,"We are facing trouble contacting our server.\nPlease check your internet connection.",Toast.LENGTH_LONG).show();
        }
        finally {
            return total;
        }
    }
    String getMatchDetails(String b, String d) {
        return getContentFromServer("cricinshort/forapp/mproc/index2.php","op=3&in="+ Uri.encode(b,"US-ASCII")+"&in1="+ Uri.encode(d,"US-ASCII"));
    }

    void getMatchDetails(String b, JSONObject c, String d) {
        String[] a = {d};
        if (d.contains("/*\\")) {
            a = d.split("/\\*\\\\");
        }
        //a = (d.contains("/\\"))?d.split("/\\\\\\"):{d};
        d = getMatchDetails(b, d);
        if(d.length()==0)
            return;
        String[] e = new String[a.length];
        try {
            e[0]=(c.has(a[0]))?c.getString(a[0]):"{}";
            int i;
            for(i=1; i<a.length; i++)
                e[i]=(((new JSONObject(e[i-1])).has(a[i]))?((new JSONObject(e[i-1])).getString(a[i])):"{}");
            e[i-1]=d;
            for(i-=2; i>=0; i--)
                e[i] = new JSONObject(e[i]).put(a[i + 1], e[i + 1]).toString();
            c.put(a[0],e[0]);
        }
        catch(JSONException er) {
            return;
        }
    }

    void getMatchData_local(){

    }

}
//mImageView.setImageBitmap(bitmap);
