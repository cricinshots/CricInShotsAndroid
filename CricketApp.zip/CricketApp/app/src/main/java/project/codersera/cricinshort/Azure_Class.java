package project.codersera.cricinshort;

public class Azure_Class {


}