package project.codersera.cricinshort;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.azure.cosmos.ConnectionPolicy;
import com.azure.cosmos.ConsistencyLevel;
import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.internal.Database;
import com.azure.cosmos.internal.DocumentCollection;
import com.azure.cosmos.internal.DocumentServiceRequestContext;


import java.io.IOException;
import java.text.ParseException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.azure.cosmos.internal.HttpConstants.HttpHeaders.HOST;
import static com.azure.cosmos.internal.TestConfigurations.MASTER_KEY;

    public class Azure extends AppCompatActivity {
     CosmosClient client;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_azure);
    }

    public String connectToDB() throws IOException, ParseException, JSONException {

        client = new CosmosClientBuilder()
                .setEndpoint("https://cricinshots-cosmos.documents.azure.com:443/")
                .setKey("rU3gW9CFsqaB3BzCzZx5t6pRelRblZ3jV0ESinPjR8gumYlR7Bcyt7Om8pHAPJnbZwxG9ssw3Lil3ry20lZs0w==")
                .setConnectionPolicy(ConnectionPolicy.getDefaultPolicy())
                .setConsistencyLevel(ConsistencyLevel.EVENTUAL)
                .buildClient();

        //CosmosClient client = new CosmosClientBuilder("https://cricinshots-cosmos.documents.azure.com:443/", "EBePsMqfcmSIwswS3nqVyazb6Q7XejtCEsfQeEpssqGNzbtp1SlD5FUBPabwLnZZvu0DT0glT0BuLMN0SpilqQ==", new ConnectionPolicy(), ConsistencyLevel.Session);

        //JSONParser parser = new JSONParser();
        // Use JSONObject for simple JSON and JSONArray for array of JSON.
        //JSONObject data = (JSONObject) parser.parse(new FileReader("C:/STSTestWorkspace/HelloCosmos/src/main/resources/test.json"));
        JSONObject data = new JSONObject();
        data.put("aDataSort", new JSONArray(0));
        data.put("aTargets", new JSONArray(1));

        return "Success";
    }


}